package com.dicom.medical.controller;

import com.dicom.medical.entity.DicomImage;
import com.dicom.medical.repository.DicomImageRepository;
import com.dicom.medical.service.DicomStorageService;
import org.dcm4che3.imageio.plugins.dcm.DicomImageReadParam;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Optional;

/**
 * ⑥ 표시 지원 — sopUid 로 .dcm 을 찾아 PNG 로 변환해 내려준다.
 *   원본: DB(DicomImage.s3Key) 조회 → 실제 경로
 *   SC  : DB에 없으므로 dicom-store/ai-sc/{sopUid}.dcm 로 바로 찾음
 */
@RestController
@RequestMapping("/api/ai")
public class DicomPreviewController {

    private final DicomImageRepository imageRepo;
    private final DicomStorageService storage;
    private static final Path SC_DIR = Path.of("dicom-store/ai-sc");

    DicomPreviewController(DicomImageRepository r, DicomStorageService s) {
        this.imageRepo = r; this.storage = s;
    }

    /** 예: GET /api/ai/preview/2.25.216918... */
    @GetMapping("/preview/{sopUid}")
    public ResponseEntity<byte[]> preview(@PathVariable String sopUid) throws Exception {
        Path dcm = resolvePath(sopUid);
        if (dcm == null || !Files.exists(dcm)) return ResponseEntity.notFound().build();

        BufferedImage img;
        try (ImageInputStream iis = ImageIO.createImageInputStream(dcm.toFile())) {
            Iterator<ImageReader> it = ImageIO.getImageReaders(iis);
            if (!it.hasNext()) throw new IllegalStateException("DICOM ImageReader 없음");
            ImageReader reader = it.next();
            reader.setInput(iis);
            DicomImageReadParam param = (DicomImageReadParam) reader.getDefaultReadParam();
            img = reader.read(0, param);   // 윈도잉·색상변환 적용된 BufferedImage
            reader.dispose();
        }

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "png", baos);
        return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG).body(baos.toByteArray());
    }

    /** sopUid → 실제 파일 경로 (원본은 DB, SC는 ai-sc 폴더) */
    private Path resolvePath(String sopUid) {
        Optional<DicomImage> found = imageRepo.findBySopInstanceUid(sopUid);
        if (found.isPresent()) {
            return storage.resolve(found.get().getS3Key());   // 원본
        }
        Path scFile = SC_DIR.resolve(sopUid + ".dcm");         // SC
        return Files.exists(scFile) ? scFile : null;
    }
}
